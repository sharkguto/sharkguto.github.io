# instalar

```bash
python3 -m pip install 'flet[all]' --upgrade
```
